package br.com.grimoireawakening.magic;

import net.minecraft.util.RandomSource;

/** Sorteios independentes da identidade: raça, clã e origem social. */
public final class CharacterRoller {
    private CharacterRoller() {}
    public record Identity(String race, String clan, String socialOrigin) {}

    public static Identity roll(RandomSource random) {
        String race = weighted(random, new String[]{"HUMAN", "ELF", "DWARF"}, new int[]{970, 25, 5});
        // Plebeu é origem social, não clã. Personagens sem linhagem recebem NO_CLAN.
        String clan = weighted(random, new String[]{"NO_CLAN", "SILVA", "VERMILLION", "KIRA", "GRINBERRYALL"}, new int[]{650, 130, 120, 70, 30});
        String origin = weighted(random, new String[]{"PEASANT", "COMMONER", "WEALTHY", "NOBLE", "ROYALTY"}, new int[]{400, 350, 140, 90, 20});
        return new Identity(race, clan, origin);
    }

    private static String weighted(RandomSource random, String[] values, int[] weights) {
        int total = 0; for (int weight : weights) total += weight;
        int roll = random.nextInt(total);
        for (int i = 0; i < values.length; i++) { roll -= weights[i]; if (roll < 0) return values[i]; }
        return values[0];
    }
}
