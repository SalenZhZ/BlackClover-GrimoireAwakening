package br.com.grimoireawakening.network;

import br.com.grimoireawakening.GrimoireAwakening;
import br.com.grimoireawakening.magic.CharacterRoller;
import br.com.grimoireawakening.magic.GrimoireRarity;
import br.com.grimoireawakening.magic.GrimoireRoller;
import br.com.grimoireawakening.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import java.util.function.Supplier;

public final class NetworkHandler {
    private static final String VERSION = "2";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new net.minecraft.resources.ResourceLocation(GrimoireAwakening.MOD_ID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals);
    private static int id = 0;
    private static final String KEY = "GrimoireAwakeningData";
    private NetworkHandler() {}

    public static void register() {
        CHANNEL.messageBuilder(OpenScreen.class, id++).encoder((m,b)->{}).decoder(b->new OpenScreen()).consumerMainThread((m,s)->DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> net.minecraft.client.Minecraft.getInstance().setScreen(new br.com.grimoireawakening.client.CeremonyScreen()))).add();
        CHANNEL.messageBuilder(RollStage.class, id++).encoder((m,b)->b.writeVarInt(m.stage)).decoder(b->new RollStage(b.readVarInt())).consumerMainThread((m,s)->handleIdentityRoll(m,s)).add();
        CHANNEL.messageBuilder(StageResult.class, id++).encoder((m,b)->{b.writeVarInt(m.stage);b.writeUtf(m.value);b.writeBoolean(m.finished);}).decoder(b->new StageResult(b.readVarInt(),b.readUtf(128),b.readBoolean())).consumerMainThread((m,s)->DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> net.minecraft.client.Minecraft.getInstance().execute(()->{if(net.minecraft.client.Minecraft.getInstance().screen instanceof br.com.grimoireawakening.client.CeremonyScreen screen) screen.acceptResult(m.stage,m.value,m.finished);}))).add();
        CHANNEL.messageBuilder(OpenMagicScreen.class, id++).encoder((m,b)->{}).decoder(b->new OpenMagicScreen()).consumerMainThread((m,s)->DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> net.minecraft.client.Minecraft.getInstance().setScreen(new br.com.grimoireawakening.client.MagicScreen()))).add();
        CHANNEL.messageBuilder(RollMagic.class, id++).encoder((m,b)->{}).decoder(b->new RollMagic()).consumerMainThread((m,s)->handleMagicRoll(s)).add();
        CHANNEL.messageBuilder(MagicResult.class, id++).encoder((m,b)->b.writeUtf(m.value)).decoder(b->new MagicResult(b.readUtf(128))).consumerMainThread((m,s)->DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> net.minecraft.client.Minecraft.getInstance().execute(()->{if(net.minecraft.client.Minecraft.getInstance().screen instanceof br.com.grimoireawakening.client.MagicScreen screen) screen.acceptResult(m.value);}))).add();
    }
    public static void open(ServerPlayer player) { CHANNEL.send(PacketDistributor.PLAYER.with(()->player), new OpenScreen()); }
    public static void openMagic(ServerPlayer player) { CompoundTag data=player.getPersistentData().getCompound(KEY); if(!data.getBoolean("character_created") || data.getBoolean("has_received_grimoire")) return; data.putBoolean("magic_ritual_open", true); player.getPersistentData().put(KEY,data); CHANNEL.send(PacketDistributor.PLAYER.with(()->player), new OpenMagicScreen()); }

    private static void handleIdentityRoll(RollStage msg, Supplier<NetworkEvent.Context> supplier) {
        ServerPlayer player=supplier.get().getSender(); if(player==null)return;
        player.getServer().execute(()->{
            CompoundTag root=player.getPersistentData(); CompoundTag data=root.getCompound(KEY);
            if(data.getBoolean("character_created") || msg.stage<0 || msg.stage>2)return;
            int expected=data.getInt("ceremony_stage"); if(msg.stage!=expected)return;
            if(msg.stage==0 && !data.getBoolean("ceremony_prepared")) {
                CharacterRoller.Identity identity=CharacterRoller.roll(player.getRandom());
                data.putString("race",identity.race()); data.putString("clan",identity.clan()); data.putString("social_origin",identity.socialOrigin()); data.putBoolean("ceremony_prepared",true);
            }
            String value=switch(msg.stage){case 0->translate(data.getString("race"));case 1->translate(data.getString("clan"));default->translate(data.getString("social_origin"));};
            data.putInt("ceremony_stage",expected+1);
            boolean finished=msg.stage==2;
            if(finished){data.putBoolean("character_created",true);player.sendSystemMessage(Component.literal("Sua origem foi definida. Encontre o Guardião na Torre dos Grimórios!").withStyle(ChatFormatting.GOLD));}
            root.put(KEY,data); CHANNEL.send(PacketDistributor.PLAYER.with(()->player),new StageResult(msg.stage,value,finished));
        });
    }

    private static void handleMagicRoll(Supplier<NetworkEvent.Context> supplier) {
        ServerPlayer player=supplier.get().getSender(); if(player==null)return;
        player.getServer().execute(()->{
            CompoundTag root=player.getPersistentData(); CompoundTag data=root.getCompound(KEY);
            if(!data.getBoolean("character_created") || data.getBoolean("has_received_grimoire") || !data.getBoolean("magic_ritual_open"))return;
            data.putBoolean("magic_ritual_open", false);
            GrimoireRoller.Result result=GrimoireRoller.roll(player.getRandom());
            data.putString("magic_attribute",result.attribute().name()); data.putString("grimoire_rarity",result.rarity().name());
            data.putBoolean("anti_magic_eligible",result.rarity()==GrimoireRarity.FIVE_LEAF); data.putBoolean("has_received_grimoire",true); root.put(KEY,data);
            ItemStack book=new ItemStack(ModItems.GRIMOIRE.get());
            CompoundTag tag=book.getOrCreateTag(); tag.putString("magic_attribute",result.attribute().displayName()); tag.putString("grimoire_rarity",result.rarity().name()); tag.putInt("leaves",result.rarity().leaves()); tag.putBoolean("anti_magic_eligible",data.getBoolean("anti_magic_eligible"));
            book.setHoverName(Component.literal("Grimório misterioso").withStyle(ChatFormatting.DARK_GREEN));
            if(!player.getInventory().add(book))player.drop(book,false);
            CHANNEL.send(PacketDistributor.PLAYER.with(()->player),new MagicResult(result.attribute().displayName()));
        });
    }

    private static String translate(String raw){return switch(raw){case "HUMAN"->"Humano";case "ELF"->"Elfo";case "DWARF"->"Anão";case "NO_CLAN"->"Sem clã";case "SILVA"->"Silva";case "VERMILLION"->"Vermillion";case "KIRA"->"Kira";case "GRINBERRYALL"->"Grinberryall";case "PEASANT"->"Camponês";case "COMMONER"->"Plebeu";case "WEALTHY"->"Rico";case "NOBLE"->"Nobre";case "ROYALTY"->"Realeza";default->raw;};}
    public record OpenScreen() {}
    public record RollStage(int stage) {}
    public record StageResult(int stage,String value,boolean finished) {}
    public record OpenMagicScreen() {}
    public record RollMagic() {}
    public record MagicResult(String value) {}
}
