package br.com.grimoireawakening.client;

import br.com.grimoireawakening.network.NetworkHandler;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import java.util.ArrayList;
import java.util.List;

public class CeremonyScreen extends Screen {
    private static final String[] LABELS={"RAÇA", "CLÃ", "ORIGEM SOCIAL"};
    private static final String[][] OPTIONS={{"Humano", "Elfo", "Anão"},{"Sem clã", "Silva", "Vermillion", "Kira", "Grinberryall"},{"Camponês", "Plebeu", "Rico", "Nobre", "Realeza"}};
    private final RandomSource random=RandomSource.create(); private final List<String> results=new ArrayList<>();
    private int stage=0, ticks=0, duration=0; private boolean spinning=false, finished=false, waiting=false; private String current="Pronto para a cerimônia"; private Button rollButton;
    public CeremonyScreen(){super(Component.literal("Cerimônia de Origem"));}
    @Override protected void init(){int c=width/2; rollButton=addRenderableWidget(Button.builder(Component.literal("RODAR"),b->startRoll()).bounds(c-70,height-48,140,25).build());}
    private void startRoll(){if(spinning||finished||waiting)return; spinning=true;ticks=0;duration=150+stage*35;rollButton.active=false;}
    @Override public void tick(){super.tick();if(!spinning)return;ticks++;int interval=ticks<duration*0.55?2:ticks<duration*0.78?4:ticks<duration*0.92?7:11;if(ticks%interval==0)current=OPTIONS[stage][random.nextInt(OPTIONS[stage].length)];if(ticks>=duration){spinning=false;waiting=true;NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.RollStage(stage));current="Revelando resultado...";}}
    public void acceptResult(int receivedStage,String value,boolean done){if(receivedStage!=stage)return;current=value;results.add(value);finished=done;waiting=false;if(!done)stage++;if(rollButton!=null){rollButton.setMessage(Component.literal(finished?"ORIGEM DEFINIDA":"PRÓXIMA — RODAR"));rollButton.active=!finished;}}
    private ChatFormatting rarityColor(int index,String value){if(index==0)return switch(value){case "Elfo"->ChatFormatting.LIGHT_PURPLE;case "Anão"->ChatFormatting.BLUE;default->ChatFormatting.GRAY;};if(index==1)return switch(value){case "Grinberryall"->ChatFormatting.GOLD;case "Kira"->ChatFormatting.DARK_PURPLE;case "Silva","Vermillion"->ChatFormatting.BLUE;default->ChatFormatting.GRAY;};return switch(value){case "Realeza"->ChatFormatting.GOLD;case "Nobre"->ChatFormatting.BLUE;case "Rico"->ChatFormatting.GREEN;default->ChatFormatting.GRAY;};}
    @Override public void render(GuiGraphics g,int mx,int my,float pt){renderBackground(g);int c=width/2;g.fill(c-150,22,c+150,height-20,0xF010101B);g.renderOutline(c-150,22,300,height-42,0xFFD5B45C);g.drawCenteredString(font,Component.literal("CERIMÔNIA DE ORIGEM").withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD),c,35,0xffffff);g.drawCenteredString(font,Component.literal("Etapa "+Math.min(stage+1,3)+" de 3 — "+(finished?"Concluída":LABELS[Math.min(stage,2)]).toLowerCase()).withStyle(ChatFormatting.GRAY),c,55,0xffffff);for(int i=0;i<3;i++){int y=88+i*54;g.drawCenteredString(font,Component.literal(LABELS[i]).withStyle(ChatFormatting.GRAY),c,y,0xffffff);g.fill(c-112,y+13,c+112,y+35,0xff29293a);String val=i<results.size()?results.get(i):i==stage?current:"Aguardando...";ChatFormatting color=i<results.size()?rarityColor(i,val):ChatFormatting.AQUA;g.drawCenteredString(font,Component.literal(val).withStyle(color,ChatFormatting.BOLD),c,y+20,0xffffff);}if(spinning)g.drawCenteredString(font,Component.literal("O destino está girando...").withStyle(ChatFormatting.YELLOW),c,height-67,0xffffff);if(waiting)g.drawCenteredString(font,Component.literal("Aguardando o destino...").withStyle(ChatFormatting.YELLOW),c,height-67,0xffffff);if(finished)g.drawCenteredString(font,Component.literal("ORIGEM DEFINIDA! Procure a Torre de Grimórios.").withStyle(ChatFormatting.GREEN,ChatFormatting.BOLD),c,height-67,0xffffff);super.render(g,mx,my,pt);}
    @Override public void onClose(){if(finished)super.onClose();}
    @Override public boolean isPauseScreen(){return false;}
}
