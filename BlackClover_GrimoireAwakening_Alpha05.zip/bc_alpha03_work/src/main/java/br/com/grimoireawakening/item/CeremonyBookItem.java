package br.com.grimoireawakening.item;

import br.com.grimoireawakening.network.NetworkHandler;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class CeremonyBookItem extends Item {
    public CeremonyBookItem(Properties properties){super(properties);}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){ItemStack stack=player.getItemInHand(hand);if(level.isClientSide)return InteractionResultHolder.sidedSuccess(stack,true);if(!(player instanceof ServerPlayer serverPlayer))return InteractionResultHolder.fail(stack);
        if(serverPlayer.getPersistentData().getCompound("GrimoireAwakeningData").getBoolean("character_created") || serverPlayer.getPersistentData().getCompound("GrimoireAwakeningData").getBoolean("has_received_grimoire")){serverPlayer.sendSystemMessage(Component.literal("Você já concluiu sua cerimônia.").withStyle(ChatFormatting.RED));return InteractionResultHolder.success(stack);}
        stack.shrink(1);NetworkHandler.open(serverPlayer);return InteractionResultHolder.success(stack);
    }
}
