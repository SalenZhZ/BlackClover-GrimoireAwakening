# Black Clover: Grimoire Awakening — Alpha 0.1

Projeto inicial para Minecraft Java 1.20.1 / Forge 47.x / Java 17.

## O que já está implementado
- Estrutura Forge com registro de itens.
- Livro da Cerimônia.
- Rolagem executada no servidor.
- Atributo mágico e raridade gravados no NBT persistente do jogador.
- Uma única rolagem por jogador, inclusive após morte ou reconexão.
- Grimório recebido com atributo e raridade gravados no NBT do item.
- Textos em português brasileiro e inglês.

## Probabilidades iniciais
- Grimório de cinco folhas: 0,1%.
- Grimório de quatro folhas: 3%.
- Grimório de três folhas: 96,9%.
- Antimagia: 0,01% (rolagem separada do atributo).

Esses valores são provisórios e serão configuráveis/balanceados em versões futuras.

## Como abrir e compilar
1. Instale um JDK 17.
2. Baixe o Forge MDK 1.20.1 (Forge 47.2.0 ou compatível).
3. Copie os arquivos deste projeto para a pasta do MDK, substituindo os arquivos de build quando solicitado.
4. Abra a pasta no IntelliJ IDEA ou Eclipse como projeto Gradle.
5. Execute `gradlew genIntellijRuns` (IntelliJ) ou `gradlew genEclipseRuns` (Eclipse).
6. Execute `gradlew runClient` para testar.
7. Execute `gradlew build` para gerar o JAR em `build/libs`.

No Linux/macOS use `./gradlew` se o wrapper estiver presente no MDK. O wrapper não está incluído neste pacote; use o wrapper que acompanha o Forge MDK.

## Teste rápido em jogo
Use `/give @s grimoireawakening:ceremony_book` para obter o livro de cerimônia.
Segure o item e use o botão direito. A primeira utilização concede um grimório.
Tente usar outro livro de cerimônia: o jogador já registrado não receberá uma segunda rolagem.

## Próximos passos
- Interface da cerimônia e animação.
- Mais atributos e tabelas de raridade configuráveis.
- Sistema de mana, nível, XP e maestria.
- Magias ativas com sincronização multiplayer.
- Estruturas, reinos, NPCs, criaturas e dungeons.

A flag de grimório também é copiada no evento `PlayerEvent.Clone`, para manter a escolha ao renascer.

## Compilar sem computador (GitHub Actions)
1. Crie um repositório vazio no GitHub.
2. Envie o conteúdo desta pasta para a raiz do repositório (incluindo a pasta `.github`).
3. Abra a aba Actions e selecione `Build Minecraft mod`.
4. Se necessário, clique em `Run workflow`.
5. Quando terminar, abra a execução concluída e baixe o artefato `grimoireawakening-alpha01`.
6. Extraia o artefato e copie o JAR para a pasta `mods` da instalação Forge 1.20.1.

O workflow compila com Java 17 e Gradle 8.8. Se a compilação falhar, consulte o log da etapa `Build mod`; o código-fonte desta Alpha ainda precisa ser validado numa compilação real.


## Alpha 0.2 – identidade inicial

Esta atualização adiciona quatro resultados independentes à cerimônia: raça (humano, elfo ou anão), clã (plebeu ou famílias Silva, Vermillion, Kira e Grinberryall), origem social (camponês, plebeu, rico, nobre ou realeza) e atributo/raridade do grimório. Os resultados ficam gravados nos dados persistentes do jogador e também no NBT do grimório. Foram adicionados modelos e texturas pixel-art provisórias para o Livro da Cerimônia e o Grimório.

Nota: nesta etapa, os resultados são apresentados por mensagens no chat. A roleta animada em tela, a progressão por XP/maestria, os feitiços e as habilidades dependentes de itens ainda serão implementados em versões posteriores. As probabilidades atuais são valores iniciais de balanceamento e poderão ser ajustadas.
