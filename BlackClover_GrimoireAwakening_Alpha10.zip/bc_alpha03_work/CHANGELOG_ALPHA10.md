# Alpha 1.0.0

- Corrigido o modelo do ovo de invocação do Guardião.
- Grimório remodelado em 3D com capa, páginas, lombada e detalhes dourados.
- Grimório flutua ao lado do jogador quando segurado.
- Bolsinha visual na cintura quando o grimório está guardado no inventário.

Esta versão ainda precisa ser compilada pelo GitHub Actions e testada no Minecraft/Forge.
