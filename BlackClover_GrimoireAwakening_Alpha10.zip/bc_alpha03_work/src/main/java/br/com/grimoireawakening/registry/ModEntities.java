package br.com.grimoireawakening.registry;

import br.com.grimoireawakening.GrimoireAwakening;
import br.com.grimoireawakening.entity.GrimoireKeeperEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, GrimoireAwakening.MOD_ID);
    public static final RegistryObject<EntityType<GrimoireKeeperEntity>> GRIMOIRE_KEEPER = ENTITY_TYPES.register("grimoire_keeper", () -> EntityType.Builder.<GrimoireKeeperEntity>of(GrimoireKeeperEntity::new, MobCategory.MISC).sized(0.6F, 1.95F).clientTrackingRange(8).build("grimoire_keeper"));
    public static void register(IEventBus bus) { ENTITY_TYPES.register(bus); }
}
