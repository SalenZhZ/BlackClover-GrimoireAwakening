package br.com.grimoireawakening.magic;

import net.minecraft.util.RandomSource;

/** Sorteios independentes. Os tipos separados impedem misturar clã e origem social. */
public final class CharacterRoller {
    private CharacterRoller() {}

    public enum Race { HUMAN, ELF, DWARF }
    public enum Clan { NO_CLAN, SILVA, VERMILLION, KIRA, GRINBERRYALL }
    public enum SocialOrigin { PEASANT, COMMONER, WEALTHY, NOBLE, ROYALTY }

    public record Identity(Race race, Clan clan, SocialOrigin socialOrigin) {}

    public static Identity roll(RandomSource random) {
        Race race = weighted(random, Race.values(), new int[]{970, 25, 5});
        Clan clan = weighted(random, Clan.values(), new int[]{650, 130, 120, 70, 30});
        SocialOrigin origin = weighted(random, SocialOrigin.values(), new int[]{400, 350, 140, 90, 20});
        return new Identity(race, clan, origin);
    }

    private static <T> T weighted(RandomSource random, T[] values, int[] weights) {
        if (values.length != weights.length || values.length == 0) {
            throw new IllegalArgumentException("Values and weights must have the same non-zero length");
        }
        int total = 0;
        for (int weight : weights) {
            if (weight < 0) throw new IllegalArgumentException("Weights cannot be negative");
            total += weight;
        }
        if (total <= 0) throw new IllegalArgumentException("At least one weight must be positive");
        int roll = random.nextInt(total);
        for (int i = 0; i < values.length; i++) {
            roll -= weights[i];
            if (roll < 0) return values[i];
        }
        throw new IllegalStateException("Weighted selection failed");
    }
}
