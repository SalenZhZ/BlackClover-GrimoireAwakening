package br.com.grimoireawakening.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class GrimoireItem extends Item {
    public GrimoireItem(Properties properties) { super(properties); }
    @Override public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, level, entity, slot, selected);
        if (level.isClientSide || !(entity instanceof Player player) || !selected) return;
        var tag = stack.getOrCreateTag();
        if (tag.getBoolean("leaves_revealed")) return;
        int leaves = tag.getInt("leaves");
        String magic = tag.getString("magic_attribute");
        player.displayClientMessage(Component.literal("Seu grimório revelou " + leaves + " folhas!").withStyle(leaves == 5 ? ChatFormatting.GOLD : leaves == 4 ? ChatFormatting.LIGHT_PURPLE : ChatFormatting.GRAY), true);
        stack.setHoverName(Component.literal("Grimório de " + magic + " — " + leaves + " folhas").withStyle(leaves == 5 ? ChatFormatting.GOLD : leaves == 4 ? ChatFormatting.LIGHT_PURPLE : ChatFormatting.GRAY));
        tag.putBoolean("leaves_revealed", true);
    }
}
