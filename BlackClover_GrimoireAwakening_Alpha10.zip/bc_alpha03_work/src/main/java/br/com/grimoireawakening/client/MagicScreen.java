package br.com.grimoireawakening.client;

import br.com.grimoireawakening.network.NetworkHandler;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;

public class MagicScreen extends Screen {
    private static final String[] ATTRIBUTES={"Fogo","Água","Vento","Terra","Relâmpago","Espacial","Planta","Gelo","Aço","Fios","Fumaça","Cristal","Escuridão","Luz","Tempo","Gravidade","Sangue","Espelho"};
    private final RandomSource random=RandomSource.create(); private Button rollButton; private int ticks=0,duration=0; private boolean spinning=false,waiting=false,finished=false; private String current="Aproxime-se para receber seu grimório";
    public MagicScreen(){super(Component.literal("Torre dos Grimórios"));}
    @Override protected void init(){rollButton=addRenderableWidget(Button.builder(Component.literal("RODAR MAGIA"),b->start()).bounds(width/2-75,height-55,150,27).build());}
    private void start(){if(spinning||waiting||finished)return;spinning=true;ticks=0;duration=190;rollButton.active=false;}
    @Override public void tick(){super.tick();if(!spinning)return;ticks++;int interval=ticks<100?2:ticks<145?4:ticks<170?7:12;if(ticks%interval==0)current=ATTRIBUTES[random.nextInt(ATTRIBUTES.length)];if(ticks>=duration){spinning=false;waiting=true;current="A magia está sendo revelada...";NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.RollMagic());}}
    public void acceptResult(String value){current=value;waiting=false;finished=true;if(rollButton!=null){rollButton.setMessage(Component.literal("MAGIA REVELADA"));rollButton.active=false;}}
    @Override public void render(GuiGraphics g,int mx,int my,float pt){renderBackground(g);int c=width/2;g.fill(c-160,35,c+160,height-30,0xF010101B);g.renderOutline(c-160,35,320,height-65,0xffd5b45c);g.drawCenteredString(font,Component.literal("TORRE DOS GRIMÓRIOS").withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD),c,55,0xffffff);g.drawCenteredString(font,Component.literal("CERIMÔNIA DO ATRIBUTO MÁGICO").withStyle(ChatFormatting.GRAY),c,78,0xffffff);g.fill(c-125,125,c+125,190,0xff29293a);g.renderOutline(c-125,125,250,65,finished?0xffffd700:0xff8060b0);g.drawCenteredString(font,Component.literal(current).withStyle(finished?ChatFormatting.GOLD:ChatFormatting.AQUA,ChatFormatting.BOLD),c,153,0xffffff);if(spinning)g.drawCenteredString(font,Component.literal("A magia está escolhendo seu portador...").withStyle(ChatFormatting.YELLOW),c,height-85,0xffffff);if(waiting)g.drawCenteredString(font,Component.literal("Aguardando a revelação...").withStyle(ChatFormatting.YELLOW),c,height-85,0xffffff);if(finished)g.drawCenteredString(font,Component.literal("Segure o grimório para descobrir suas folhas!").withStyle(ChatFormatting.GREEN),c,height-85,0xffffff);super.render(g,mx,my,pt);}
    @Override public boolean isPauseScreen(){return false;}
}
