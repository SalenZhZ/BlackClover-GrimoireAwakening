package br.com.grimoireawakening.entity;

import br.com.grimoireawakening.GrimoireAwakening;
import br.com.grimoireawakening.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GrimoireAwakening.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class GrimoireKeeperAttributes {
    private GrimoireKeeperAttributes() {}
    @SubscribeEvent public static void register(EntityAttributeCreationEvent event) {
        event.put(ModEntities.GRIMOIRE_KEEPER.get(), GrimoireKeeperEntity.createAttributes().build());
    }
}
