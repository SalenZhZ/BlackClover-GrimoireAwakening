package br.com.grimoireawakening.item;

import br.com.grimoireawakening.network.NetworkHandler;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class CeremonyBookItem extends Item {
    public CeremonyBookItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(stack, true);
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResultHolder.fail(stack);

        var data = serverPlayer.getPersistentData().getCompound("GrimoireAwakeningData");
        if (data.getBoolean("character_created") || data.getBoolean("has_received_grimoire")) {
            serverPlayer.sendSystemMessage(Component.literal("Você já concluiu sua cerimônia.").withStyle(ChatFormatting.RED));
            return InteractionResultHolder.success(stack);
        }

        // Marca a cerimônia antes de consumir o item: se o jogador sair do mundo,
        // o progresso será retomado automaticamente ao entrar novamente.
        if (!data.getBoolean("ceremony_started")) {
            data.putBoolean("ceremony_started", true);
            serverPlayer.getPersistentData().put("GrimoireAwakeningData", data);
            stack.shrink(1);
        }
        NetworkHandler.open(serverPlayer);
        return InteractionResultHolder.success(stack);
    }
}
