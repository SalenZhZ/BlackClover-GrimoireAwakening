package br.com.grimoireawakening.entity;

import br.com.grimoireawakening.network.NetworkHandler;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class GrimoireKeeperEntity extends PathfinderMob {
    public GrimoireKeeperEntity(EntityType<? extends PathfinderMob> type, Level level) { super(type, level); this.setNoAi(true); this.setCustomName(Component.translatable("entity.grimoireawakening.grimoire_keeper")); this.setCustomNameVisible(true); }
    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, 30.0D).add(Attributes.MOVEMENT_SPEED, 0.0D);
    }
    @Override protected void registerGoals() {}
    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!level().isClientSide && player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) NetworkHandler.openMagic(serverPlayer);
        return InteractionResult.sidedSuccess(level().isClientSide);
    }
}
