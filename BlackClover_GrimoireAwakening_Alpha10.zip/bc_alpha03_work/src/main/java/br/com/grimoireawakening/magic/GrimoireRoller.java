package br.com.grimoireawakening.magic;

import net.minecraft.util.RandomSource;

public final class GrimoireRoller {
    private GrimoireRoller() {}

    public record Result(MagicAttribute attribute, GrimoireRarity rarity) {}

    public static Result roll(RandomSource random) {
        GrimoireRarity rarity = rollRarity(random);
        // Antimagia não participa da roleta comum de atributos. Um grimório
        // de cinco folhas apenas torna o personagem elegível para esse poder especial.
        MagicAttribute attribute = weightedAttribute(random);
        return new Result(attribute, rarity);
    }

    private static MagicAttribute weightedAttribute(RandomSource random) {
        // Magias especiais têm chance menor que os atributos comuns.
        if (random.nextInt(100) < 3) {
            MagicAttribute[] rare = {
                    MagicAttribute.TIME, MagicAttribute.LIGHT, MagicAttribute.DARKNESS,
                    MagicAttribute.GRAVITY, MagicAttribute.SPATIAL, MagicAttribute.BLOOD,
                    MagicAttribute.MIRROR
            };
            return rare[random.nextInt(rare.length)];
        }

        MagicAttribute[] common = {
                MagicAttribute.FIRE, MagicAttribute.WATER, MagicAttribute.WIND,
                MagicAttribute.EARTH, MagicAttribute.LIGHTNING, MagicAttribute.PLANT,
                MagicAttribute.ICE, MagicAttribute.STEEL, MagicAttribute.THREAD,
                MagicAttribute.SMOKE, MagicAttribute.CRYSTAL
        };
        return common[random.nextInt(common.length)];
    }

    private static GrimoireRarity rollRarity(RandomSource random) {
        // Distribuição aprovada: 85% / 12% / 3%.
        int roll = random.nextInt(100);
        if (roll < 3) return GrimoireRarity.FIVE_LEAF;
        if (roll < 15) return GrimoireRarity.FOUR_LEAF;
        return GrimoireRarity.THREE_LEAF;
    }
}
