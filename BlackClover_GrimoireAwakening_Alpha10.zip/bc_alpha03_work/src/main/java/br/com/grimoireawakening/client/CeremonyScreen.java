package br.com.grimoireawakening.client;

import br.com.grimoireawakening.network.NetworkHandler;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import java.util.ArrayList;
import java.util.List;

public class CeremonyScreen extends Screen {
    private static final String[] LABELS = {"RAÇA", "CLÃ", "ORIGEM SOCIAL"};
    private static final String[][] OPTIONS = {
            {"Humano", "Elfo", "Anão"},
            {"Sem clã", "Silva", "Vermillion", "Kira", "Grinberryall"},
            {"Camponês", "Plebeu", "Rico", "Nobre", "Realeza"}
    };

    private final RandomSource random = RandomSource.create();
    private final List<String> results = new ArrayList<>();
    private int stage;
    private int ticks;
    private int duration;
    private boolean spinning;
    private boolean finished;
    private boolean waiting;
    private String current = "Pronto para a cerimônia";
    private Button rollButton;

    public CeremonyScreen(int resumeStage, String race, String clan, String origin) {
        super(Component.literal("Cerimônia de Origem"));
        stage = Math.max(0, Math.min(2, resumeStage));
        if (stage >= 1 && !race.isBlank()) results.add(race);
        if (stage >= 2 && !clan.isBlank()) results.add(clan);
        current = switch (stage) {
            case 1 -> "Raça definida";
            case 2 -> "Clã definido";
            default -> "Pronto para a cerimônia";
        };
    }

    @Override protected void init() {
        int center = width / 2;
        rollButton = addRenderableWidget(Button.builder(Component.literal(stage == 0 ? "RODAR" : "CONTINUAR — RODAR"), b -> startRoll())
                .bounds(center - 70, height - 48, 140, 25).build());
    }

    private void startRoll() {
        if (spinning || finished || waiting || stage > 2) return;
        spinning = true;
        ticks = 0;
        duration = 150 + stage * 35;
        rollButton.active = false;
    }

    @Override public void tick() {
        super.tick();
        if (!spinning) return;
        ticks++;
        int interval = ticks < duration * 0.55 ? 2 : ticks < duration * 0.78 ? 4 : ticks < duration * 0.92 ? 7 : 11;
        if (ticks % interval == 0) current = OPTIONS[stage][random.nextInt(OPTIONS[stage].length)];
        if (ticks >= duration) {
            spinning = false;
            waiting = true;
            NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.RollStage(stage));
            current = "Revelando resultado...";
        }
    }

    public void acceptResult(int receivedStage, String value, boolean done) {
        if (receivedStage != stage || !waiting) return;
        if (results.size() == receivedStage) results.add(value);
        else if (results.size() > receivedStage) results.set(receivedStage, value);
        current = value;
        finished = done;
        waiting = false;
        if (!done) stage++;
        if (rollButton != null) {
            rollButton.setMessage(Component.literal(finished ? "ORIGEM DEFINIDA" : "PRÓXIMA — RODAR"));
            rollButton.active = !finished;
        }
    }

    private ChatFormatting rarityColor(int index, String value) {
        if (index == 0) return switch (value) {
            case "Elfo" -> ChatFormatting.LIGHT_PURPLE;
            case "Anão" -> ChatFormatting.BLUE;
            default -> ChatFormatting.GRAY;
        };
        if (index == 1) return switch (value) {
            case "Grinberryall" -> ChatFormatting.GOLD;
            case "Kira" -> ChatFormatting.DARK_PURPLE;
            case "Silva", "Vermillion" -> ChatFormatting.BLUE;
            default -> ChatFormatting.GRAY;
        };
        return switch (value) {
            case "Realeza" -> ChatFormatting.GOLD;
            case "Nobre" -> ChatFormatting.BLUE;
            case "Rico" -> ChatFormatting.GREEN;
            default -> ChatFormatting.GRAY;
        };
    }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        int center = width / 2;
        graphics.fill(center - 150, 22, center + 150, height - 20, 0xF010101B);
        graphics.renderOutline(center - 150, 22, 300, height - 42, 0xFFD5B45C);
        graphics.drawCenteredString(font, Component.literal("CERIMÔNIA DE ORIGEM").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), center, 35, 0xffffff);
        String stageName = finished ? "Concluída" : LABELS[Math.min(stage, 2)];
        graphics.drawCenteredString(font, Component.literal("Etapa " + (finished ? 3 : stage + 1) + " de 3 — " + stageName).withStyle(ChatFormatting.GRAY), center, 55, 0xffffff);

        for (int i = 0; i < 3; i++) {
            int y = 88 + i * 54;
            graphics.drawCenteredString(font, Component.literal(LABELS[i]).withStyle(ChatFormatting.GRAY), center, y, 0xffffff);
            graphics.fill(center - 112, y + 13, center + 112, y + 35, 0xff29293a);
            String value = i < results.size() ? results.get(i) : i == stage && !finished ? current : "Aguardando...";
            ChatFormatting color = i < results.size() ? rarityColor(i, value) : ChatFormatting.AQUA;
            graphics.drawCenteredString(font, Component.literal(value).withStyle(color, ChatFormatting.BOLD), center, y + 20, 0xffffff);
        }
        if (spinning) graphics.drawCenteredString(font, Component.literal("O destino está girando...").withStyle(ChatFormatting.YELLOW), center, height - 67, 0xffffff);
        if (waiting) graphics.drawCenteredString(font, Component.literal("Aguardando o destino...").withStyle(ChatFormatting.YELLOW), center, height - 67, 0xffffff);
        if (finished) graphics.drawCenteredString(font, Component.literal("ORIGEM DEFINIDA! Procure a Torre de Grimórios.").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), center, height - 67, 0xffffff);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public void onClose() {
        if (finished) super.onClose();
    }

    @Override public boolean isPauseScreen() { return false; }
}
