package br.com.grimoireawakening.event;

import br.com.grimoireawakening.network.NetworkHandler;
import br.com.grimoireawakening.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "grimoireawakening")
public final class PlayerDataEvents {
    private static final String DATA_KEY = "GrimoireAwakeningData";
    private PlayerDataEvents() {}

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        CompoundTag oldData = event.getOriginal().getPersistentData();
        CompoundTag newData = event.getEntity().getPersistentData();
        if (oldData.contains(DATA_KEY)) newData.put(DATA_KEY, oldData.getCompound(DATA_KEY).copy());
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity().level().isClientSide || !(event.getEntity() instanceof net.minecraft.server.level.ServerPlayer player)) return;
        CompoundTag data = player.getPersistentData().getCompound(DATA_KEY);

        if (data.getBoolean("ceremony_started") && !data.getBoolean("character_created")) {
            NetworkHandler.open(player);
            return;
        }

        if (!data.getBoolean("ceremony_book_given") && !data.getBoolean("character_created") && !data.getBoolean("has_received_grimoire")) {
            ItemStack book = new ItemStack(ModItems.CEREMONY_BOOK.get());
            if (!player.getInventory().add(book)) player.drop(book, false);
            data.putBoolean("ceremony_book_given", true);
            player.getPersistentData().put(DATA_KEY, data);
        }
    }
}
