package br.com.grimoireawakening.magic;

public enum GrimoireRarity {
    THREE_LEAF("Três folhas", 3),
    FOUR_LEAF("Quatro folhas", 4),
    FIVE_LEAF("Cinco folhas", 5);
    private final String displayName;
    private final int leaves;
    GrimoireRarity(String displayName, int leaves) { this.displayName = displayName; this.leaves = leaves; }
    public String displayName() { return displayName; }
    public int leaves() { return leaves; }
}
