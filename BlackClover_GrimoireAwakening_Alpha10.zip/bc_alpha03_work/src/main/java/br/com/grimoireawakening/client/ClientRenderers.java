package br.com.grimoireawakening.client;

import br.com.grimoireawakening.GrimoireAwakening;
import br.com.grimoireawakening.entity.GrimoireKeeperEntity;
import br.com.grimoireawakening.registry.ModEntities;
import net.minecraft.client.model.VillagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GrimoireAwakening.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientRenderers {
    private ClientRenderers() {}
    @SubscribeEvent public static void register(EntityRenderersEvent.RegisterRenderers event) { event.registerEntityRenderer(ModEntities.GRIMOIRE_KEEPER.get(), KeeperRenderer::new); }
    private static class KeeperRenderer extends MobRenderer<GrimoireKeeperEntity, VillagerModel<GrimoireKeeperEntity>> {
        KeeperRenderer(EntityRendererProvider.Context context) { super(context, new VillagerModel<>(context.bakeLayer(ModelLayers.VILLAGER)), 0.5F); }
        @Override public ResourceLocation getTextureLocation(GrimoireKeeperEntity entity) { return new ResourceLocation("minecraft", "textures/entity/villager/villager.png"); }
    }
}
