# Alpha 0.6 — correções

- Separação rígida dos tipos `Race`, `Clan` e `SocialOrigin`; `COMMONER`/Plebeu não pode mais ser selecionado nem traduzido como clã.
- A lista de clãs aceita somente Sem clã, Silva, Vermillion, Kira e Grinberryall.
- A cerimônia salva o estado antes de consumir o Livro da Cerimônia.
- Se o jogador sair durante a cerimônia, a tela reabre na etapa correta ao entrar novamente, preservando os resultados já sorteados.
- Mantidas as probabilidades de grimório: 85% três folhas, 12% quatro folhas e 3% cinco folhas.
- Mantido o fluxo da Torre: o Guardião sorteia apenas o atributo mágico; as folhas só são reveladas quando o grimório é segurado.
- Mantidos o modelo 3D do grimório e as cores visuais das categorias.
