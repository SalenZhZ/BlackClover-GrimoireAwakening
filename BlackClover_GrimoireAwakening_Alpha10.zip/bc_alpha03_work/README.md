# Black Clover: Grimoire Awakening — Alpha 0.6

Minecraft Java 1.20.1 · Forge 47.2.0 · Java 17

## Cerimônia de origem
- O jogador recebe o Livro da Cerimônia ao entrar pela primeira vez.
- Usar o livro consome o item e abre a interface.
- A cerimônia inicial agora tem somente três etapas: raça, clã e origem social.
- Cada etapa começa apenas ao clicar em RODAR, com animação mais lenta e desaceleração. Se o jogador sair durante a cerimônia, ela retoma na etapa correta ao entrar novamente.
- Raça, clã e origem social agora usam tipos separados no código. Plebeu só pode ser origem social; a lista de clãs aceita exclusivamente Sem clã, Silva, Vermillion, Kira e Grinberryall.
- Os resultados usam cores visuais associadas às categorias de raridade.

## Torre dos Grimórios
- Depois de concluir a origem, o jogador precisa encontrar o Guardião da Torre dos Grimórios.
- O Guardião é uma entidade própria do mod, disponível pelo Ovo do Guardião na aba Ferramentas e Utilidades do Criativo.
- Coloque o Guardião na torre construída pelo jogador e converse com ele para abrir a roleta do atributo mágico.
- A roleta da torre sorteia apenas o atributo mágico. A raridade do grimório não aparece na tela.
- O Guardião só permite a cerimônia a quem já concluiu a origem e ainda não recebeu grimório.

## Revelação do grimório
- Ao receber o item, ele aparece como “Grimório misterioso”.
- Quando o jogador segura o grimório pela primeira vez, o item revela quantas folhas possui e atualiza seu nome.
- O modelo do item agora usa geometria 3D no inventário e na mão.
- Chances: três folhas 85%, quatro folhas 12%, cinco folhas 3%.
- Apenas grimórios de cinco folhas tornam o personagem elegível para o sistema futuro de Anti-Magia. Anti-Magia não é um atributo normal sorteável.

## Observação sobre a torre
Esta Alpha inclui o NPC Guardião e seu ovo de invocação. A geração automática de uma estrutura de torre no mundo ainda não está incluída: por enquanto, construa a torre e coloque o Guardião nela.

## Compilação e validação
Requer JDK 17 e Forge MDK 1.20.1 / 47.2.0. O wrapper Gradle não está incluído. Execute `gradle build` em um ambiente com Gradle 8.8. Esta entrega contém o código-fonte corrigido. A compilação Forge não foi executada neste ambiente porque o Gradle não está instalado; o workflow do GitHub Actions compila com Gradle 8.8 e Java 17. O JAR só deve ser considerado pronto depois que esse workflow terminar com sucesso e o mod for testado no jogo.


## Alpha 1.0.0 – aparência do grimório

O grimório recebeu um modelo tridimensional em camadas, com capa, páginas, lombada e detalhes dourados. No cliente, ele é renderizado flutuando ao lado do jogador quando está na mão; se estiver guardado no inventário, aparece encaixado em uma bolsinha na cintura. O ovo do Guardião agora possui um modelo de item baseado no modelo padrão de ovos de invocação do Minecraft.
