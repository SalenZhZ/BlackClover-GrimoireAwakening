# Alpha 0.7

- Corrigida a criação do ovo de invocação do Guardião: o registro da entidade agora é resolvido com `RegistryObject.get()` ao criar o item, fornecendo ao `SpawnEggItem` o `EntityType` esperado pelo Forge 1.20.1.

Esta correção resolve o erro de tipo apontado em `ModItems.java` durante `compileJava`. A compilação completa ainda precisa ser confirmada pelo GitHub Actions.
