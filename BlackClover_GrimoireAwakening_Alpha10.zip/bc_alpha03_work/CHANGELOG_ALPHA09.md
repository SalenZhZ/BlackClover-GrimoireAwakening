# Alpha 0.9

- Corrigida a classe do ovo de invocação para `ForgeSpawnEggItem`, disponível no Forge 1.20.1.
- Mantido o registro adiado da entidade por meio de `ModEntities.GRIMOIRE_KEEPER` como `Supplier`, sem chamar `.get()` durante o registro dos itens.
- Versão do mod atualizada para `0.9.0` para facilitar a identificação do novo JAR.

Esta versão contém código-fonte. A compilação ainda precisa ser confirmada pelo GitHub Actions.
