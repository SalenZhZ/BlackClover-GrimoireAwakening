package br.com.grimoireawakening.registry;

import br.com.grimoireawakening.GrimoireAwakening;
import br.com.grimoireawakening.item.CeremonyBookItem;
import br.com.grimoireawakening.item.GrimoireItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, GrimoireAwakening.MOD_ID);
    public static final RegistryObject<Item> CEREMONY_BOOK = ITEMS.register("ceremony_book", () -> new CeremonyBookItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> GRIMOIRE = ITEMS.register("grimoire", () -> new GrimoireItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> KEEPER_SPAWN_EGG = ITEMS.register("grimoire_keeper_spawn_egg", () -> new SpawnEggItem(ModEntities.GRIMOIRE_KEEPER.get(), 0x30213F, 0xD6B85A, new Item.Properties()));
    public static void register(IEventBus eventBus) { ITEMS.register(eventBus); }
}
