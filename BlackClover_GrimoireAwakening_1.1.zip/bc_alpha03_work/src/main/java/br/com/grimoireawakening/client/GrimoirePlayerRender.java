package br.com.grimoireawakening.client;

import br.com.grimoireawakening.GrimoireAwakening;
import br.com.grimoireawakening.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GrimoireAwakening.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class GrimoirePlayerRender {
    private GrimoirePlayerRender() {}

    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Post event) {
        Player player = event.getEntity();
        if (player.isInvisible() || player.isSpectator()) return;

        boolean held = player.getMainHandItem().is(ModItems.GRIMOIRE.get())
                || player.getOffhandItem().is(ModItems.GRIMOIRE.get());
        boolean carried = player.getInventory().contains(new ItemStack(ModItems.GRIMOIRE.get()));
        if (!held && !carried) return;

        PoseStack pose = event.getPoseStack();
        pose.pushPose();
        if (held) {
            float animationTime = player.tickCount + event.getPartialTick();
            float bob = (float) Math.sin(animationTime * 0.12F) * 0.045F;
            float spin = (animationTime * 1.8F) % 360.0F;
            pose.translate(0.43D, 1.05D + bob, 0.12D);
            pose.mulPose(Axis.YP.rotationDegrees(spin));
            pose.mulPose(Axis.ZP.rotationDegrees(-12.0F));
            pose.scale(0.62F, 0.62F, 0.62F);
            renderStack(event, new ItemStack(ModItems.GRIMOIRE.get()));
        } else {
            pose.translate(-0.34D, 0.18D, 0.19D);
            pose.mulPose(Axis.YP.rotationDegrees(90.0F));
            pose.mulPose(Axis.ZP.rotationDegrees(-8.0F));
            pose.scale(0.52F, 0.52F, 0.52F);
            renderStack(event, new ItemStack(ModItems.GRIMOIRE_POUCH.get()));
            pose.translate(0.0D, 0.20D, 0.10D);
            pose.mulPose(Axis.XP.rotationDegrees(-18.0F));
            pose.scale(0.82F, 0.82F, 0.82F);
            renderStack(event, new ItemStack(ModItems.GRIMOIRE.get()));
        }
        pose.popPose();
    }

    private static void renderStack(RenderPlayerEvent.Post event, ItemStack stack) {
        Minecraft.getInstance().getItemRenderer().renderStatic(
                stack, ItemDisplayContext.FIXED, event.getPackedLight(), OverlayTexture.NO_OVERLAY,
                event.getPoseStack(), event.getMultiBufferSource(), event.getEntity().level(), event.getEntity().getId());
    }
}
