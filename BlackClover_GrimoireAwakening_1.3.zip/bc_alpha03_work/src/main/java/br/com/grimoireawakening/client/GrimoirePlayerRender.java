package br.com.grimoireawakening.client;

import br.com.grimoireawakening.GrimoireAwakening;
import br.com.grimoireawakening.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.WeakHashMap;

@Mod.EventBusSubscriber(modid = GrimoireAwakening.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class GrimoirePlayerRender {
    /* Temporarily hide the held stack while the third-person player model is rendered.
       The original stack is restored immediately in RenderPlayerEvent.Post. */
    private static final Map<Player, HeldGrimoires> HIDDEN_HELD_ITEMS = new WeakHashMap<>();

    private GrimoirePlayerRender() {}

    @SubscribeEvent
    public static void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
        Player player = event.getEntity();
        if (player.isInvisible() || player.isSpectator()) return;

        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();
        boolean mainIsGrimoire = main.is(ModItems.GRIMOIRE.get());
        boolean offIsGrimoire = off.is(ModItems.GRIMOIRE.get());
        if (!mainIsGrimoire && !offIsGrimoire) return;

        HIDDEN_HELD_ITEMS.put(player, new HeldGrimoires(
                mainIsGrimoire ? main : ItemStack.EMPTY,
                offIsGrimoire ? off : ItemStack.EMPTY));
        if (mainIsGrimoire) player.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        if (offIsGrimoire) player.setItemInHand(InteractionHand.OFF_HAND, ItemStack.EMPTY);
    }

    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Post event) {
        Player player = event.getEntity();
        if (player.isInvisible() || player.isSpectator()) return;

        HeldGrimoires heldItems = HIDDEN_HELD_ITEMS.remove(player);
        boolean held = heldItems != null;
        if (heldItems != null) {
            if (!heldItems.mainHand.isEmpty()) player.setItemInHand(InteractionHand.MAIN_HAND, heldItems.mainHand);
            if (!heldItems.offHand.isEmpty()) player.setItemInHand(InteractionHand.OFF_HAND, heldItems.offHand);
        }

        boolean carried = player.getInventory().contains(new ItemStack(ModItems.GRIMOIRE.get()));
        if (!held && !carried) return;

        PoseStack pose = event.getPoseStack();
        pose.pushPose();
        if (held) {
            // Equipped grimoires float beside the player; they are never rendered in either hand.
            // Slow, continuous levitation: gentle vertical bob, side drift and subtle tilt.
            // Partial tick keeps the motion smooth between game ticks.
            float animationTime = player.tickCount + event.getPartialTick();
            float phase = animationTime * 0.055F;
            float bob = (float) Math.sin(phase) * 0.055F;
            float drift = (float) Math.sin(phase * 0.65F) * 0.035F;
            float yaw = -18.0F + (float) Math.sin(phase * 0.8F) * 3.0F;
            float roll = -8.0F + (float) Math.sin(phase) * 2.5F;
            pose.translate(0.43D + drift, 1.08D + bob, 0.12D);
            pose.mulPose(Axis.YP.rotationDegrees(yaw));
            pose.mulPose(Axis.XP.rotationDegrees((float) Math.sin(phase * 0.7F) * 2.0F));
            pose.mulPose(Axis.ZP.rotationDegrees(roll));
            pose.scale(0.62F, 0.62F, 0.62F);
            renderStack(event, new ItemStack(ModItems.GRIMOIRE.get()));
        } else {
            pose.translate(-0.34D, 0.18D, 0.19D);
            pose.mulPose(Axis.YP.rotationDegrees(90.0F));
            pose.mulPose(Axis.ZP.rotationDegrees(-8.0F));
            pose.scale(0.52F, 0.52F, 0.52F);
            renderStack(event, new ItemStack(ModItems.GRIMOIRE_POUCH.get()));
            pose.translate(0.0D, 0.20D, 0.10D);
            pose.mulPose(Axis.XP.rotationDegrees(-18.0F));
            pose.scale(0.82F, 0.82F, 0.82F);
            renderStack(event, new ItemStack(ModItems.GRIMOIRE.get()));
        }
        pose.popPose();
    }

    @SubscribeEvent
    public static void onRenderFirstPersonHand(RenderHandEvent event) {
        if (!event.getItemStack().is(ModItems.GRIMOIRE.get())) return;

        // Replace the first-person held-item model with a small floating copy in front
        // of the camera, instead of showing the book attached to the hand.
        Minecraft minecraft = Minecraft.getInstance();
        Player player = minecraft.player;
        if (player == null || player.level() == null) {
            event.setCanceled(true);
            return;
        }
        PoseStack pose = event.getPoseStack();
        pose.pushPose();
        float time = player.tickCount + event.getPartialTick();
        float phase = time * 0.055F;
        float bob = (float) Math.sin(phase) * 0.035F;
        float drift = (float) Math.sin(phase * 0.65F) * 0.025F;
        pose.translate(0.48D + drift, -0.18D + bob, -0.72D);
        pose.mulPose(Axis.YP.rotationDegrees(-18.0F + (float) Math.sin(phase * 0.8F) * 2.5F));
        pose.mulPose(Axis.XP.rotationDegrees((float) Math.sin(phase * 0.7F) * 1.5F));
        pose.mulPose(Axis.ZP.rotationDegrees(-8.0F + (float) Math.sin(phase) * 2.0F));
        pose.scale(0.34F, 0.34F, 0.34F);
        minecraft.getItemRenderer().renderStatic(
                new ItemStack(ModItems.GRIMOIRE.get()), ItemDisplayContext.FIXED,
                event.getPackedLight(), OverlayTexture.NO_OVERLAY, pose,
                event.getMultiBufferSource(), player.level(), player.getId());
        pose.popPose();
        event.setCanceled(true);
    }

    private static void renderStack(RenderPlayerEvent.Post event, ItemStack stack) {
        Minecraft.getInstance().getItemRenderer().renderStatic(
                stack, ItemDisplayContext.FIXED, event.getPackedLight(), OverlayTexture.NO_OVERLAY,
                event.getPoseStack(), event.getMultiBufferSource(), event.getEntity().level(), event.getEntity().getId());
    }

    private record HeldGrimoires(ItemStack mainHand, ItemStack offHand) {}
}
