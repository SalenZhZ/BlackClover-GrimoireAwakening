# Version 1.3.0

Visual corrections to the grimoire (no new gameplay features):
- Rebuilt the item model as an open book with two separate page leaves, covers and a visible spine instead of a closed cuboid.
- Smoothed the floating animation with slower vertical bob, subtle side drift and gentle tilt.
- Kept the equipped book displayed as a floating object rather than in the player's hand.
