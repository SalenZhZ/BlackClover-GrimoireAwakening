package br.com.grimoireawakening.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.ChatFormatting;

/** Tela de cerimônia: animação visual enquanto o servidor realiza os sorteios reais. */
public class CeremonyScreen extends Screen {
    private static final String[][] OPTIONS = {
            {"Humano", "Elfo", "Anão"},
            {"Silva", "Vermillion", "Kira", "Grinberryall", "Plebeu"},
            {"Camponês", "Plebeu", "Rico", "Nobre", "Realeza"},
            {"3 folhas", "4 folhas", "5 folhas"}
    };
    private static final String[] LABELS = {"RAÇA", "CLÃ", "ORIGEM SOCIAL", "GRIMÓRIO"};
    private final RandomSource random = RandomSource.create();
    private final String[] shown = new String[4];
    private int ticks;

    public CeremonyScreen() {
        super(Component.literal("Cerimônia dos Grimórios"));
        for (int i = 0; i < shown.length; i++) shown[i] = OPTIONS[i][0];
    }

    @Override
    public void tick() {
        super.tick();
        ticks++;
        for (int i = 0; i < shown.length; i++) {
            if (ticks < 28 + i * 9) {
                shown[i] = OPTIONS[i][random.nextInt(OPTIONS[i].length)];
            }
        }
        if (ticks >= 70) onClose();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        int center = width / 2;
        graphics.fill(center - 145, 35, center + 145, height - 35, 0xE910101B);
        graphics.renderOutline(center - 145, 35, 290, height - 70, 0xFFD5B45C);
        graphics.drawCenteredString(font, Component.literal("CERIMÔNIA DOS GRIMÓRIOS").withStyle(ChatFormatting.GOLD), center, 52, 0xFFFFFF);
        graphics.drawCenteredString(font, Component.literal("O destino está sendo decidido...").withStyle(ChatFormatting.GRAY), center, 70, 0xFFFFFF);
        for (int i = 0; i < 4; i++) {
            int y = 103 + i * 48;
            boolean stopped = ticks >= 28 + i * 9;
            int color = stopped ? 0xFFFFD76A : 0xFFB9D7FF;
            graphics.drawCenteredString(font, Component.literal(LABELS[i]).withStyle(ChatFormatting.GRAY), center, y, 0xFFFFFF);
            graphics.fill(center - 112, y + 13, center + 112, y + 39, 0xFF29293A);
            graphics.renderOutline(center - 112, y + 13, 224, 26, stopped ? 0xFFD5B45C : 0xFF7777A0);
            graphics.drawCenteredString(font, Component.literal(shown[i]).withStyle(stopped ? ChatFormatting.GOLD : ChatFormatting.AQUA), center, y + 21, color);
        }
        if (ticks >= 60) {
            graphics.drawCenteredString(font, Component.literal("DESTINO REVELADO!").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), center, height - 58, 0xFFFFFF);
            graphics.drawCenteredString(font, Component.literal("Confira os resultados no chat.").withStyle(ChatFormatting.GRAY), center, height - 45, 0xFFFFFF);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
}
