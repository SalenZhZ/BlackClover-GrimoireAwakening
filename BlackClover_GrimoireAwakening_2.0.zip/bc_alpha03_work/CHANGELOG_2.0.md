# Black Clover – Grimoire Awakening 2.0.0

## Novo sistema de técnicas mágicas
- Catálogo com 6 técnicas para cada um dos 19 atributos mágicos (114 entradas).
- Técnicas conhecidas do anime/mangá priorizadas; entradas criadas para o mod identificadas como `[Exclusiva do mod]`.
- Clique direito com o grimório para conjurar a técnica selecionada.
- Shift + clique direito para alternar entre as técnicas do atributo.
- Sistema inicial de mana (100 pontos), regeneração, custos, recargas e requisitos de nível.
- Efeitos de partículas por atributo e aplicação inicial de dano/efeitos no alvo à frente.
- Atualização da versão do projeto para 2.0.0.

## Controles
- Botão direito: conjurar.
- Shift + botão direito: selecionar a próxima técnica.

## Limitações desta primeira etapa
- As técnicas compartilham uma base inicial de conjuração; ainda não há animações individuais, projéteis customizados, invocações, transformação de armaduras ou efeitos exclusivos completos para cada habilidade.
- O sistema precisa passar por compilação Forge 47.2.0 e testes dentro do Minecraft antes de ser considerado validado.
