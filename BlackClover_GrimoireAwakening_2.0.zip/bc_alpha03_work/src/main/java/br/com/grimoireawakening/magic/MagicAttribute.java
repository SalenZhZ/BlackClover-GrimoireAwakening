package br.com.grimoireawakening.magic;

public enum MagicAttribute {
    FIRE("Fogo"),
    WATER("Água"),
    WIND("Vento"),
    EARTH("Terra"),
    LIGHTNING("Relâmpago"),
    SPATIAL("Espacial"),
    PLANT("Planta"),
    ICE("Gelo"),
    STEEL("Aço"),
    THREAD("Fios"),
    SMOKE("Fumaça"),
    CRYSTAL("Cristal"),
    DARKNESS("Escuridão"),
    LIGHT("Luz"),
    TIME("Tempo"),
    GRAVITY("Gravidade"),
    BLOOD("Sangue"),
    MIRROR("Espelho"),
    ANTI_MAGIC("Antimagia");

    private final String displayName;

    MagicAttribute(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return displayName;
    }

    public static MagicAttribute fromDisplayName(String value) {
        for (MagicAttribute attribute : values()) {
            if (attribute.displayName.equalsIgnoreCase(value) || attribute.name().equalsIgnoreCase(value)) return attribute;
        }
        return FIRE;
    }
}
