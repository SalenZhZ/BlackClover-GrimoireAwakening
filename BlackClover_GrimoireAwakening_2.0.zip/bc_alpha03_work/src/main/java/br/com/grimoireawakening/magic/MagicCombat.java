package br.com.grimoireawakening.magic;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import java.util.Comparator;
import java.util.List;

public final class MagicCombat {
    private static final String DATA_KEY = "GrimoireAwakeningCombat";
    private static final int MAX_MANA = 100;
    private MagicCombat() {}

    public static void useGrimoire(Player player, ItemStack stack) {
        MagicAttribute attribute = MagicAttribute.fromDisplayName(stack.getOrCreateTag().getString("magic_attribute"));
        List<SpellCatalog.Spell> spells = SpellCatalog.get(attribute);
        if (spells.isEmpty()) return;
        var data = player.getPersistentData().getCompound(DATA_KEY);
        int selected = Math.floorMod(data.getInt("selected_spell"), spells.size());
        if (player.isShiftKeyDown()) {
            selected = (selected + 1) % spells.size();
            data.putInt("selected_spell", selected);
            player.getPersistentData().put(DATA_KEY, data);
            SpellCatalog.Spell next = spells.get(selected);
            player.displayClientMessage(Component.literal("Técnica selecionada: " + next.name() + " (" + (selected + 1) + "/" + spells.size() + ")").withStyle(ChatFormatting.AQUA), true);
            return;
        }
        SpellCatalog.Spell spell = spells.get(selected);
        int level = player.experienceLevel;
        if (level < spell.requiredLevel()) {
            player.displayClientMessage(Component.literal("Você precisa do nível " + spell.requiredLevel() + " para usar " + spell.name() + ".").withStyle(ChatFormatting.RED), true);
            return;
        }
        long now = player.level().getGameTime();
        long readyAt = data.getLong("cooldown_" + selected);
        if (now < readyAt) {
            player.displayClientMessage(Component.literal("Técnica recarregando: " + Math.max(1, (readyAt - now + 19) / 20) + "s").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        int mana = data.contains("mana") ? data.getInt("mana") : MAX_MANA;
        if (mana < spell.manaCost()) {
            player.displayClientMessage(Component.literal("Mana insuficiente: " + mana + "/" + MAX_MANA).withStyle(ChatFormatting.RED), true);
            return;
        }
        data.putInt("mana", mana - spell.manaCost());
        data.putLong("cooldown_" + selected, now + spell.cooldownSeconds() * 20L);
        player.getPersistentData().put(DATA_KEY, data);
        castEffect(player, attribute, spell);
        player.displayClientMessage(Component.literal(spell.name() + "!  Mana: " + (mana - spell.manaCost()) + "/" + MAX_MANA).withStyle(ChatFormatting.GOLD), true);
    }

    private static void castEffect(Player player, MagicAttribute attribute, SpellCatalog.Spell spell) {
        if (!(player.level() instanceof ServerLevel level)) return;
        Vec3 look = player.getLookAngle().normalize();
        Vec3 center = player.position().add(look.scale(3.0)).add(0, 1.0, 0);
        var particle = switch (attribute) {
            case FIRE -> ParticleTypes.FLAME;
            case WATER, ICE -> ParticleTypes.SPLASH;
            case WIND, SPATIAL -> ParticleTypes.CLOUD;
            case EARTH, STEEL, CRYSTAL -> ParticleTypes.CRIT;
            case LIGHTNING, LIGHT -> ParticleTypes.ELECTRIC_SPARK;
            case PLANT, THREAD -> ParticleTypes.HAPPY_VILLAGER;
            case DARKNESS, ANTI_MAGIC -> ParticleTypes.SMOKE;
            case TIME, GRAVITY -> ParticleTypes.PORTAL;
            case BLOOD -> ParticleTypes.DAMAGE_INDICATOR;
            case MIRROR -> ParticleTypes.END_ROD;
            case SMOKE -> ParticleTypes.LARGE_SMOKE;
        };
        level.sendParticles(particle, center.x, center.y, center.z, 35, 0.8, 0.8, 0.8, 0.08);
        if (spell.damage() > 0) {
            double range = 8.0;
            AABB search = player.getBoundingBox().inflate(range);
            LivingEntity target = level.getEntitiesOfClass(LivingEntity.class, search,
                    entity -> entity != player && entity.isAlive() && !entity.isAlliedTo(player))
                    .stream().filter(entity -> {
                        Vec3 to = entity.getEyePosition().subtract(player.getEyePosition()).normalize();
                        return look.dot(to) > 0.35;
                    }).min(Comparator.comparingDouble(entity -> entity.distanceToSqr(player))).orElse(null);
            if (target != null) {
                target.hurt(player.damageSources().playerAttack(player), spell.damage());
                if (spell.requiredLevel() >= 1) target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 35, 0));
                level.sendParticles(particle, target.getX(), target.getY() + 1, target.getZ(), 24, 0.45, 0.65, 0.45, 0.06);
            }
        } else {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 0));
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0));
        }
    }

    public static void regenerateMana(Player player) {
        if (player.level().isClientSide || player.tickCount % 20 != 0) return;
        var data = player.getPersistentData().getCompound(DATA_KEY);
        int mana = data.contains("mana") ? data.getInt("mana") : MAX_MANA;
        if (mana < MAX_MANA) {
            data.putInt("mana", Math.min(MAX_MANA, mana + 2));
            player.getPersistentData().put(DATA_KEY, data);
        }
    }
}
