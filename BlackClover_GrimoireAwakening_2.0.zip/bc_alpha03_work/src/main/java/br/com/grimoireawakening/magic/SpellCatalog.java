package br.com.grimoireawakening.magic;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Spell list for the first combat-system implementation. Canonical techniques are
 * identified in their descriptions; entries marked [Exclusiva do mod] are original. */
public final class SpellCatalog {
    private static final Map<MagicAttribute, List<Spell>> SPELLS = new EnumMap<>(MagicAttribute.class);
    static {
        add(MagicAttribute.FIRE,
            s("Calidus Brachium", "Mereoleona — técnica de fogo concentrada", 12, 7, 45, 1, false),
            s("Salamandra", "Invocação do espírito elemental do fogo", 18, 10, 90, 2, false),
            s("Exploding Fireball", "Magia de Fogo Explosiva de Magna", 14, 8, 55, 1, false),
            s("Chuva de Brasas", "[Exclusiva do mod] Rajada de projéteis flamejantes", 9, 6, 35, 0, true),
            s("Manto de Chamas", "[Exclusiva do mod] Envolve o grimorista em fogo", 8, 5, 40, 1, true),
            s("Erupção Carmesim", "[Exclusiva do mod] Explosão flamejante em área", 22, 11, 110, 3, true));
        add(MagicAttribute.WATER,
            s("Sea Dragon's Roar", "Rugido do Dragão do Mar de Noelle", 18, 10, 80, 2, false),
            s("Sea Dragon's Cradle", "Cúpula protetora de água de Noelle", 0, 8, 65, 1, false),
            s("Valkyrie Dress", "Armadura de água de Noelle", 0, 7, 75, 1, false),
            s("Lança das Marés", "[Exclusiva do mod] Lança de água de longo alcance", 10, 7, 35, 0, true),
            s("Prisão Abissal", "[Exclusiva do mod] Aprisiona o alvo em água", 5, 6, 50, 1, true),
            s("Tsunami Real", "[Exclusiva do mod] Grande onda que atinge uma área", 20, 10, 100, 3, true));
        add(MagicAttribute.WIND,
            s("Spirit Storm", "Rajada espiritual de vento", 15, 9, 65, 1, false),
            s("Sylph's Breath", "Técnica de vento associada a Bell", 10, 7, 45, 0, false),
            s("Tornado Fang", "Investida cortante de vento", 13, 7, 50, 1, false),
            s("Lâminas do Vendaval", "[Exclusiva do mod] Várias lâminas de vento", 11, 7, 35, 0, true),
            s("Passo dos Céus", "[Exclusiva do mod] Impulso de vento para mobilidade", 0, 6, 40, 1, true),
            s("Ciclone Imperial", "[Exclusiva do mod] Ciclone de grande alcance", 21, 11, 105, 3, true));
        add(MagicAttribute.EARTH,
            s("Earth Magic: Golem", "Golem de terra", 15, 9, 70, 2, false),
            s("Earth Magic: Rock Fall", "Queda de rochas", 14, 8, 55, 1, false),
            s("Earth Magic: Stone Wall", "Muralha de pedra", 0, 6, 45, 1, false),
            s("Punho Sísmico", "[Exclusiva do mod] Golpe de terra", 12, 7, 35, 0, true),
            s("Estacas Rochosas", "[Exclusiva do mod] Estacas surgem sob o alvo", 13, 7, 45, 1, true),
            s("Colosso Terrestre", "[Exclusiva do mod] Impacto sísmico em área", 22, 12, 110, 3, true));
        add(MagicAttribute.LIGHTNING,
            s("Thunder God's Boots", "Técnica elétrica de Luck", 12, 7, 45, 1, false),
            s("Lightning Battle Fiend", "Forma de combate elétrica de Luck", 0, 8, 70, 1, false),
            s("Thunderclap", "Ataque rápido de relâmpago", 15, 8, 55, 1, false),
            s("Raio Perfurante", "[Exclusiva do mod] Disparo elétrico concentrado", 13, 7, 35, 0, true),
            s("Campo Estático", "[Exclusiva do mod] Descarga em inimigos próximos", 10, 6, 50, 1, true),
            s("Julgamento Celeste", "[Exclusiva do mod] Grande descarga elétrica", 23, 11, 110, 3, true));
        add(MagicAttribute.SPATIAL,
            s("Fallen Angel's Wingbeat", "Técnica espacial de Finral", 0, 8, 65, 1, false),
            s("Spatial Trap", "Armadilha espacial", 8, 7, 50, 1, false),
            s("Spatial Severing", "Corte espacial de Langris", 20, 10, 85, 2, false),
            s("Dobra Instantânea", "[Exclusiva do mod] Deslocamento curto", 0, 5, 35, 0, true),
            s("Prisão Dimensional", "[Exclusiva do mod] Imobiliza o alvo", 6, 7, 55, 1, true),
            s("Ruptura do Espaço", "[Exclusiva do mod] Ruptura espacial em área", 22, 12, 115, 3, true));
        add(MagicAttribute.PLANT,
            s("Flower Princess Utopia", "Técnica de magia de plantas", 0, 8, 65, 1, false),
            s("Magic Flower Garden", "Jardim mágico de flores", 8, 7, 55, 1, false),
            s("Clematis", "Técnica de plantas de Rill", 12, 8, 60, 1, false),
            s("Chicote de Espinhos", "[Exclusiva do mod] Chicote vegetal", 11, 7, 35, 0, true),
            s("Raízes Aprisionadoras", "[Exclusiva do mod] Raízes prendem o alvo", 5, 6, 45, 1, true),
            s("Floresta Colossal", "[Exclusiva do mod] Explosão de raízes em área", 20, 11, 105, 3, true));
        add(MagicAttribute.ICE,
            s("Ice Coffin", "Caixão de gelo", 15, 9, 65, 2, false),
            s("Ice Make: Lance", "Lança de gelo", 12, 7, 40, 0, false),
            s("Ice Magic: Ice Wall", "Muralha de gelo", 0, 6, 45, 1, false),
            s("Agulhas Glaciais", "[Exclusiva do mod] Rajada de estilhaços", 10, 7, 35, 0, true),
            s("Prisão Congelante", "[Exclusiva do mod] Congela o alvo", 5, 7, 50, 1, true),
            s("Tempestade Glacial", "[Exclusiva do mod] Nevasca ofensiva", 21, 11, 105, 3, true));
        add(MagicAttribute.STEEL,
            s("Steel Magic: Steel Spear", "Lança de aço", 13, 7, 45, 1, false),
            s("Steel Magic: Steel Fist", "Punho de aço", 12, 6, 40, 0, false),
            s("Steel Magic: Steel Armor", "Armadura de aço", 0, 8, 65, 1, false),
            s("Chuva de Estilhaços", "[Exclusiva do mod] Estilhaços metálicos", 11, 7, 35, 0, true),
            s("Jaula de Aço", "[Exclusiva do mod] Aprisiona em barras", 6, 7, 55, 1, true),
            s("Titã de Ferro", "[Exclusiva do mod] Impacto de metal em área", 22, 12, 110, 3, true));
        add(MagicAttribute.THREAD,
            s("Red String of Fate", "Fios do destino de Vanessa", 0, 8, 70, 1, false),
            s("Thread Magic: Puppet Strings", "Fios que controlam movimentos", 8, 7, 55, 1, false),
            s("Thread Magic: Binding", "Amarração com fios", 6, 6, 45, 1, false),
            s("Lâmina de Fios", "[Exclusiva do mod] Fios cortantes", 12, 7, 35, 0, true),
            s("Teia Carmesim", "[Exclusiva do mod] Rede que prende alvos", 5, 6, 50, 1, true),
            s("Marionete Absoluta", "[Exclusiva do mod] Rajada de fios em área", 20, 11, 105, 3, true));
        add(MagicAttribute.SMOKE,
            s("Cortina de Fumaça", "[Exclusiva do mod] Cobre a área com fumaça", 0, 5, 35, 0, true),
            s("Projétil Nebuloso", "[Exclusiva do mod] Disparo de fumaça", 9, 6, 30, 0, true),
            s("Punho de Fuligem", "[Exclusiva do mod] Golpe de fumaça condensada", 11, 7, 40, 0, true),
            s("Névoa Asfixiante", "[Exclusiva do mod] Nuvem que enfraquece", 5, 7, 55, 1, true),
            s("Passagem Nebulosa", "[Exclusiva do mod] Movimento encoberto", 0, 6, 50, 1, true),
            s("Dragão de Fumaça", "[Exclusiva do mod] Grande criatura de fumaça", 21, 11, 105, 3, true));
        add(MagicAttribute.CRYSTAL,
            s("Crystal Creation", "Criação de cristais de Mars", 12, 7, 45, 1, false),
            s("Crystal Lance", "Lança de cristal", 13, 7, 45, 1, false),
            s("Crystal Prison", "Prisão de cristal", 6, 7, 55, 1, false),
            s("Chuva de Cristais", "[Exclusiva do mod] Dispara cristais", 11, 7, 35, 0, true),
            s("Armadura Prismática", "[Exclusiva do mod] Proteção cristalina", 0, 8, 65, 1, true),
            s("Catedral de Cristal", "[Exclusiva do mod] Explosão de cristais", 22, 12, 110, 3, true));
        add(MagicAttribute.DARKNESS,
            s("Dark Cloaked Dimension Slash", "Corte dimensional revestido de escuridão de Yami", 22, 10, 90, 2, false),
            s("Black Moon", "Defesa de escuridão de Yami", 0, 8, 70, 1, false),
            s("Dark Cloaked Lightless Slash", "Corte sem luz de Yami", 18, 9, 75, 2, false),
            s("Manto Sombrio", "[Exclusiva do mod] Aura de escuridão", 10, 7, 45, 1, true),
            s("Lança das Trevas", "[Exclusiva do mod] Projétil sombrio", 13, 7, 40, 0, true),
            s("Abismo Negro", "[Exclusiva do mod] Explosão de escuridão", 23, 12, 115, 3, true));
        add(MagicAttribute.LIGHT,
            s("Light Sword of Judgment", "Espada de luz de Patri", 18, 9, 75, 2, false),
            s("Ray of Divine Punishment", "Raio de punição divina", 16, 8, 65, 1, false),
            s("Light Magic: Light Barrage", "Rajada de luz", 12, 7, 45, 1, false),
            s("Lança Luminosa", "[Exclusiva do mod] Disparo concentrado", 13, 7, 35, 0, true),
            s("Passo da Luz", "[Exclusiva do mod] Investida veloz", 0, 6, 45, 1, true),
            s("Aurora Celestial", "[Exclusiva do mod] Explosão de luz", 22, 11, 110, 3, true));
        add(MagicAttribute.TIME,
            s("Chrono Stasis", "Paralisação temporal de Julius", 5, 10, 90, 2, false),
            s("Chrono Anastasis", "Reversão temporal de Julius", 0, 10, 100, 2, false),
            s("Time Magic: Chrono Stasis", "Esfera de contenção temporal", 8, 8, 70, 1, false),
            s("Rajada Cronal", "[Exclusiva do mod] Disparo de energia temporal", 14, 8, 55, 1, true),
            s("Passo Acelerado", "[Exclusiva do mod] Aceleração temporária", 0, 7, 65, 1, true),
            s("Ruptura do Tempo", "[Exclusiva do mod] Pulso temporal em área", 24, 12, 125, 3, true));
        add(MagicAttribute.GRAVITY,
            s("Presence of the Demon King", "Pressão gravitacional de Lucifero", 16, 10, 85, 2, false),
            s("Gravity Singularity", "Singularidade gravitacional", 22, 11, 105, 3, false),
            s("Heavy Infighting", "Combate corpo a corpo reforçado por gravidade", 15, 8, 65, 1, false),
            s("Campo de Gravidade", "[Exclusiva do mod] Pressiona inimigos próximos", 10, 7, 55, 1, true),
            s("Órbita Invertida", "[Exclusiva do mod] Arremessa o alvo", 12, 8, 60, 1, true),
            s("Colapso Gravitacional", "[Exclusiva do mod] Grande impacto gravitacional", 25, 12, 125, 3, true));
        add(MagicAttribute.BLOOD,
            s("Red Beast", "Fera de sangue da Rainha das Bruxas", 16, 9, 75, 2, false),
            s("Blood Magic: Blood Suck", "Drenagem de sangue", 10, 8, 65, 1, false),
            s("Blood Magic: Blood Rain", "Chuva de sangue", 14, 8, 65, 1, false),
            s("Lâmina Hemática", "[Exclusiva do mod] Lâmina de sangue", 12, 7, 40, 0, true),
            s("Correntes Rubras", "[Exclusiva do mod] Correntes de sangue", 6, 7, 55, 1, true),
            s("Maré Escarlate", "[Exclusiva do mod] Onda de sangue", 22, 11, 110, 3, true));
        add(MagicAttribute.MIRROR,
            s("Mirror Brigade", "Brigada de espelhos de Gauche", 14, 9, 75, 2, false),
            s("Reflect Refrain", "Reflexão de ataques por espelhos", 0, 8, 65, 1, false),
            s("Mirror Magic: Mirror Meteorite", "Projétil espelhado", 16, 8, 65, 1, false),
            s("Raio Refletido", "[Exclusiva do mod] Disparo ricocheteante", 12, 7, 40, 0, true),
            s("Prisão de Espelhos", "[Exclusiva do mod] Cela de espelhos", 6, 7, 55, 1, true),
            s("Labirinto Prismático", "[Exclusiva do mod] Rajada de reflexos", 21, 11, 105, 3, true));
        add(MagicAttribute.ANTI_MAGIC,
            s("Black Divider", "Espada antimagia de Asta", 20, 10, 90, 2, false),
            s("Black Meteorite", "Investida antimagia de Asta", 18, 9, 80, 2, false),
            s("Black Hurricane", "Redemoinho antimagia", 16, 9, 75, 2, false),
            s("Demon-Slasher Katana", "Corte com a katana Demon-Slasher", 22, 10, 95, 2, false),
            s("Corte Negro", "[Exclusiva do mod] Projétil de antimagia", 14, 8, 55, 1, true),
            s("Ruptura Antimagia", "[Exclusiva do mod] Onda de antimagia", 25, 12, 120, 3, true));
    }

    private SpellCatalog() {}
    private static Spell s(String name, String description, int damage, int mana, int cooldown, int level, boolean original) {
        return new Spell(name, description, damage, mana, cooldown, level, original);
    }
    private static void add(MagicAttribute attribute, Spell... spells) { SPELLS.put(attribute, List.of(spells)); }
    public static List<Spell> get(MagicAttribute attribute) { return SPELLS.getOrDefault(attribute, List.of()); }
    public record Spell(String name, String description, int damage, int manaCost, int cooldownSeconds, int requiredLevel, boolean original) {}
}
