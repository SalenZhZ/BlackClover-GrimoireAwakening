# Black Clover – Grimoire Awakening 1.2

## Correção visual
- Ao equipar o grimório, o modelo padrão na mão é ocultado durante a renderização do jogador.
- O grimório equipado é exibido apenas como modelo flutuante ao lado do personagem.
- A renderização do item na mão em primeira pessoa também é suprimida.
- O grimório guardado continua sendo exibido na bolsinha da cintura.

Esta atualização é uma correção visual da versão 1.x e não adiciona novas funcionalidades de jogo.
