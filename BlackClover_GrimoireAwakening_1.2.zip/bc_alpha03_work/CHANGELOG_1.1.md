# Black Clover – Grimoire Awakening 1.1

## Correções
- Corrigido o pacote de importação de `OverlayTexture` em `GrimoirePlayerRender`, que impedia a compilação no Forge 1.20.1.
- Atualizada a versão do mod para 1.1.0.

Esta atualização não adiciona funcionalidades novas; é uma correção da versão 1.0.
