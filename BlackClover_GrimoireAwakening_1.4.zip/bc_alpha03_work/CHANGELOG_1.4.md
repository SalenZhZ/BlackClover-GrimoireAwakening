# Version 1.4.0

Visual corrections only (no new gameplay features):
- Increased the opening angle of the two book halves so the grimoire reads more clearly as an open book rather than a folded cover.
- Moved the third-person floating grimoire to the opposite depth side of the player model and farther away from the torso to keep it visible in front.
- Preserved the smooth floating animation and first-person floating display.
