package br.com.grimoireawakening.event;

import br.com.grimoireawakening.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="grimoireawakening")
public final class PlayerDataEvents {
    private static final String DATA_KEY="GrimoireAwakeningData";
    private PlayerDataEvents(){}
    @SubscribeEvent public static void onPlayerClone(PlayerEvent.Clone event){CompoundTag oldData=event.getOriginal().getPersistentData();CompoundTag newData=event.getEntity().getPersistentData();if(oldData.contains(DATA_KEY))newData.put(DATA_KEY,oldData.getCompound(DATA_KEY).copy());}
    @SubscribeEvent public static void onLogin(PlayerEvent.PlayerLoggedInEvent event){if(event.getEntity().level().isClientSide)return;CompoundTag data=event.getEntity().getPersistentData().getCompound(DATA_KEY);if(!data.getBoolean("ceremony_book_given")&&!data.getBoolean("has_received_grimoire")){ItemStack book=new ItemStack(ModItems.CEREMONY_BOOK.get());if(!event.getEntity().getInventory().add(book))event.getEntity().drop(book,false);data.putBoolean("ceremony_book_given",true);event.getEntity().getPersistentData().put(DATA_KEY,data);}}
}
