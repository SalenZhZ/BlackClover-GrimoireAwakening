package br.com.grimoireawakening.client;

import br.com.grimoireawakening.network.NetworkHandler;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import java.util.ArrayList;
import java.util.List;

public class CeremonyScreen extends Screen {
    private static final String[] LABELS={"RAÇA","CLÃ","ORIGEM SOCIAL","GRIMÓRIO"};
    private static final String[][] OPTIONS={{"Humano","Elfo","Anão"},{"Silva","Vermillion","Kira","Grinberryall","Plebeu"},{"Camponês","Plebeu","Rico","Nobre","Realeza"},{"Três folhas","Quatro folhas","Cinco folhas"}};
    private final RandomSource random=RandomSource.create(); private final List<String> results=new ArrayList<>();
    private int stage=0, ticks=0, duration=0; private boolean spinning=false, finished=false; private String current="Pronto para a cerimônia"; private Button rollButton;
    public CeremonyScreen(){super(Component.literal("Cerimônia dos Grimórios"));}
    @Override protected void init(){int c=width/2; rollButton=addRenderableWidget(Button.builder(Component.literal("RODAR"),b->startRoll()).bounds(c-70,height-48,140,25).build());}
    private void startRoll(){if(spinning||finished)return; spinning=true;ticks=0;duration=100+stage*25;rollButton.active=false;}
    @Override public void tick(){super.tick();if(!spinning)return;ticks++;if(ticks%3==0)current=OPTIONS[stage][random.nextInt(OPTIONS[stage].length)];if(ticks>=duration){spinning=false;NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.RollStage(stage));current="Aguardando o resultado...";}}
    public void acceptResult(int receivedStage,String value,boolean done){if(receivedStage!=stage)return;current=value;results.add(LABELS[stage]+": "+value);finished=done;if(!done)stage++;if(rollButton!=null){rollButton.setMessage(Component.literal(finished?"CERIMÔNIA CONCLUÍDA":"PRÓXIMA ETAPA — RODAR"));rollButton.active=!finished;}}
    @Override public void render(GuiGraphics g,int mx,int my,float pt){renderBackground(g);int c=width/2;g.fill(c-150,25,c+150,height-25,0xF010101B);g.renderOutline(c-150,25,300,height-50,0xFFD5B45C);g.drawCenteredString(font,Component.literal("CERIMÔNIA DOS GRIMÓRIOS").withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD),c,40,0xffffff);g.drawCenteredString(font,Component.literal("Etapa "+Math.min(stage+1,4)+" de 4 — "+(finished?"Concluída":LABELS[Math.min(stage,3)]).toLowerCase()).withStyle(ChatFormatting.GRAY),c,60,0xffffff);for(int i=0;i<4;i++){int y=88+i*42;g.drawCenteredString(font,Component.literal(LABELS[i]).withStyle(ChatFormatting.GRAY),c,y,0xffffff);g.fill(c-112,y+13,c+112,y+35,0xff29293a);String val=i<results.size()?results.get(i):i==stage?current:"Aguardando...";g.drawCenteredString(font,Component.literal(val).withStyle(i<results.size()?ChatFormatting.GOLD:ChatFormatting.AQUA),c,y+20,0xffffff);}if(spinning)g.drawCenteredString(font,Component.literal("O destino está girando...").withStyle(ChatFormatting.YELLOW),c,height-67,0xffffff);if(finished)g.drawCenteredString(font,Component.literal("DESTINO REVELADO!").withStyle(ChatFormatting.GREEN,ChatFormatting.BOLD),c,height-67,0xffffff);super.render(g,mx,my,pt);}
    @Override public void onClose(){if(finished)super.onClose();}
    @Override public boolean isPauseScreen(){return false;}
}
