package br.com.grimoireawakening.magic;

public enum GrimoireRarity {
    THREE_LEAF("Três folhas"),
    FOUR_LEAF("Quatro folhas"),
    FIVE_LEAF("Cinco folhas");

    private final String displayName;

    GrimoireRarity(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return displayName;
    }
}
