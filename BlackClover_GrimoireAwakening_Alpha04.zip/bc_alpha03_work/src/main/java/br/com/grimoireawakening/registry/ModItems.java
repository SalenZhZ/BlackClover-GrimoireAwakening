package br.com.grimoireawakening.registry;

import br.com.grimoireawakening.GrimoireAwakening;
import br.com.grimoireawakening.item.CeremonyBookItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GrimoireAwakening.MOD_ID);

    public static final RegistryObject<Item> CEREMONY_BOOK =
            ITEMS.register("ceremony_book", () -> new CeremonyBookItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> GRIMOIRE =
            ITEMS.register("grimoire", () -> new Item(new Item.Properties().stacksTo(1)));

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
