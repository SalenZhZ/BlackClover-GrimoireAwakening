package br.com.grimoireawakening.network;

import br.com.grimoireawakening.GrimoireAwakening;
import br.com.grimoireawakening.magic.CharacterRoller;
import br.com.grimoireawakening.magic.GrimoireRarity;
import br.com.grimoireawakening.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import java.util.function.Supplier;

public final class NetworkHandler {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new net.minecraft.resources.ResourceLocation(GrimoireAwakening.MOD_ID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals);
    private static int id = 0;
    private static final String KEY = "GrimoireAwakeningData";
    private NetworkHandler() {}

    public static void register() {
        CHANNEL.messageBuilder(OpenScreen.class, id++).encoder((m,b)->{}).decoder(b->new OpenScreen()).consumerMainThread((m,s)->DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> net.minecraft.client.Minecraft.getInstance().setScreen(new br.com.grimoireawakening.client.CeremonyScreen()))).add();
        CHANNEL.messageBuilder(RollStage.class, id++).encoder((m,b)->b.writeVarInt(m.stage)).decoder(b->new RollStage(b.readVarInt())).consumerMainThread((m,s)->handleRoll(m,s)).add();
        CHANNEL.messageBuilder(StageResult.class, id++).encoder((m,b)->{b.writeVarInt(m.stage);b.writeUtf(m.value);b.writeBoolean(m.finished);}).decoder(b->new StageResult(b.readVarInt(),b.readUtf(128),b.readBoolean())).consumerMainThread((m,s)->DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> net.minecraft.client.Minecraft.getInstance().execute(()->{if(net.minecraft.client.Minecraft.getInstance().screen instanceof br.com.grimoireawakening.client.CeremonyScreen screen) screen.acceptResult(m.stage,m.value,m.finished);}))).add();
    }
    public static void open(ServerPlayer player) { CHANNEL.send(PacketDistributor.PLAYER.with(()->player), new OpenScreen()); }
    private static void handleRoll(RollStage msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx=supplier.get(); ServerPlayer player=ctx.getSender(); if(player==null)return;
        player.getServer().execute(()->{
            CompoundTag root=player.getPersistentData(); CompoundTag data=root.getCompound(KEY);
            if(data.getBoolean("has_received_grimoire")) return;
            int expected=data.getInt("ceremony_stage"); if(msg.stage!=expected || msg.stage<0 || msg.stage>3)return;
            if(msg.stage==0 && !data.getBoolean("ceremony_prepared")) {
                CharacterRoller.Identity identity=CharacterRoller.roll(player.getRandom());
                data.putString("race",identity.race()); data.putString("clan",identity.clan()); data.putString("social_origin",identity.socialOrigin());
                data.putString("magic_attribute",identity.grimoire().attribute().name()); data.putString("grimoire_rarity",identity.grimoire().rarity().name());
                data.putBoolean("anti_magic_eligible",identity.grimoire().rarity()==GrimoireRarity.FIVE_LEAF); data.putBoolean("ceremony_prepared",true);
            }
            String value=switch(msg.stage){case 0->translate(data.getString("race"));case 1->translate(data.getString("clan"));case 2->translate(data.getString("social_origin"));default->translate(data.getString("grimoire_rarity"))+" — "+translate(data.getString("magic_attribute"));};
            data.putInt("ceremony_stage",expected+1);
            boolean finished=msg.stage==3;
            if(finished){data.putBoolean("has_received_grimoire",true); ItemStack book=new ItemStack(ModItems.GRIMOIRE.get()); book.getOrCreateTag().putString("magic_attribute",data.getString("magic_attribute")); book.getOrCreateTag().putString("grimoire_rarity",data.getString("grimoire_rarity")); book.getOrCreateTag().putString("race",data.getString("race")); book.getOrCreateTag().putString("clan",data.getString("clan")); book.getOrCreateTag().putString("social_origin",data.getString("social_origin")); book.getOrCreateTag().putBoolean("anti_magic_eligible",data.getBoolean("anti_magic_eligible"));
                book.setHoverName(Component.literal("Grimório de "+data.getString("magic_attribute")).withStyle(ChatFormatting.GREEN)); if(!player.getInventory().add(book))player.drop(book,false);
            }
            root.put(KEY,data); CHANNEL.send(PacketDistributor.PLAYER.with(()->player),new StageResult(msg.stage,value,finished));
        });
    }
    private static String translate(String raw){return switch(raw){case "HUMAN"->"Humano";case "ELF"->"Elfo";case "DWARF"->"Anão";case "COMMONER"->"Plebeu";case "SILVA"->"Silva";case "VERMILLION"->"Vermillion";case "KIRA"->"Kira";case "GRINBERRYALL"->"Grinberryall";case "PEASANT"->"Camponês";case "WEALTHY"->"Rico";case "NOBLE"->"Nobre";case "ROYALTY"->"Realeza";case "THREE_LEAF"->"Três folhas";case "FOUR_LEAF"->"Quatro folhas";case "FIVE_LEAF"->"Cinco folhas";case "FIRE"->"Fogo";case "WATER"->"Água";case "WIND"->"Vento";case "EARTH"->"Terra";case "LIGHTNING"->"Relâmpago";case "SPATIAL"->"Espacial";case "PLANT"->"Planta";case "ICE"->"Gelo";case "STEEL"->"Aço";case "THREAD"->"Fios";case "SMOKE"->"Fumaça";case "CRYSTAL"->"Cristal";case "DARKNESS"->"Escuridão";case "LIGHT"->"Luz";case "TIME"->"Tempo";case "GRAVITY"->"Gravidade";case "BLOOD"->"Sangue";case "MIRROR"->"Espelho";default->raw;};}
    public record OpenScreen() {}
    public record RollStage(int stage) {}
    public record StageResult(int stage,String value,boolean finished) {}
}
