package br.com.grimoireawakening;

import br.com.grimoireawakening.registry.ModItems;
import br.com.grimoireawakening.network.NetworkHandler;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(GrimoireAwakening.MOD_ID)
public class GrimoireAwakening {
    public static final String MOD_ID = "grimoireawakening";

    public GrimoireAwakening() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.register(modBus);
        NetworkHandler.register();
        modBus.addListener(this::addCreative);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.CEREMONY_BOOK);
            event.accept(ModItems.GRIMOIRE);
        }
    }
}
