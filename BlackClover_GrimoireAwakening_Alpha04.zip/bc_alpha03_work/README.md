# Black Clover: Grimoire Awakening — Alpha 0.4

Minecraft Java 1.20.1 · Forge 47.2.0 · Java 17

## Cerimônia interativa
- O jogador recebe o Livro da Cerimônia automaticamente ao entrar pela primeira vez no mundo.
- Usar o livro consome o item e abre a tela da cerimônia.
- A tela apresenta quatro etapas sequenciais: raça, clã, origem social e grimório.
- Cada etapa só começa após clicar em **RODAR**. O jogador precisa clicar novamente para avançar à etapa seguinte.
- A animação dura mais que na Alpha 0.3 e desacelera até parar.
- Os resultados verdadeiros são sorteados e validados no servidor, depois enviados à interface; não são apenas resultados visuais.
- A tela não pode ser fechada antes de concluir a cerimônia, evitando perder o acesso após consumir o livro.
- Ao concluir, o grimório é entregue e o jogador não pode repetir a cerimônia.

## Chances de grimório
- Três folhas: 85%
- Quatro folhas: 12%
- Cinco folhas: 3%

A Anti-Magia não faz parte do sorteio normal. Apenas quem recebe grimório de cinco folhas fica elegível para o futuro sistema especial.

## Compilação
Requer JDK 17 e Forge MDK 1.20.1 / 47.2.0. O wrapper Gradle não está incluído. Abra o projeto com Gradle no IntelliJ IDEA ou Eclipse e execute `gradle build` (ou o wrapper do MDK). O JAR deverá ser gerado em `build/libs`.

**Validação:** esta entrega contém a implementação-fonte da Alpha 0.4. Não foi possível executar a compilação neste ambiente porque o comando Gradle não está instalado; compile e teste no Forge antes de usar em um mundo principal.
