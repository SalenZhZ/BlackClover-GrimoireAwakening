package br.com.grimoireawakening.magic;

import net.minecraft.util.RandomSource;

public final class GrimoireRoller {
    private GrimoireRoller() {}

    public record Result(MagicAttribute attribute, GrimoireRarity rarity) {}

    public static Result roll(RandomSource random) {
        MagicAttribute attribute = weightedAttribute(random);
        GrimoireRarity rarity = rollRarity(random);
        return new Result(attribute, rarity);
    }

    private static MagicAttribute weightedAttribute(RandomSource random) {
        // Antimagia é extremamente rara nesta primeira versão.
        if (random.nextInt(10_000) == 0) {
            return MagicAttribute.ANTI_MAGIC;
        }

        // Magias especiais têm chance menor que os atributos comuns.
        if (random.nextInt(100) < 3) {
            MagicAttribute[] rare = {
                    MagicAttribute.TIME, MagicAttribute.LIGHT, MagicAttribute.DARKNESS,
                    MagicAttribute.GRAVITY, MagicAttribute.SPATIAL, MagicAttribute.BLOOD,
                    MagicAttribute.MIRROR
            };
            return rare[random.nextInt(rare.length)];
        }

        MagicAttribute[] common = {
                MagicAttribute.FIRE, MagicAttribute.WATER, MagicAttribute.WIND,
                MagicAttribute.EARTH, MagicAttribute.LIGHTNING, MagicAttribute.PLANT,
                MagicAttribute.ICE, MagicAttribute.STEEL, MagicAttribute.THREAD,
                MagicAttribute.SMOKE, MagicAttribute.CRYSTAL
        };
        return common[random.nextInt(common.length)];
    }

    private static GrimoireRarity rollRarity(RandomSource random) {
        int roll = random.nextInt(1000);
        if (roll == 0) return GrimoireRarity.FIVE_LEAF; // 0,1%
        if (roll < 31) return GrimoireRarity.FOUR_LEAF; // 3,0%
        return GrimoireRarity.THREE_LEAF;
    }
}
