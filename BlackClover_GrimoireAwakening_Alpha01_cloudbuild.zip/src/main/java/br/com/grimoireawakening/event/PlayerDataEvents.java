package br.com.grimoireawakening.event;

import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "grimoireawakening")
public final class PlayerDataEvents {
    private static final String DATA_KEY = "GrimoireAwakeningData";

    private PlayerDataEvents() {}

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        CompoundTag oldData = event.getOriginal().getPersistentData();
        CompoundTag newData = event.getEntity().getPersistentData();

        if (oldData.contains(DATA_KEY)) {
            newData.put(DATA_KEY, oldData.getCompound(DATA_KEY).copy());
        }
    }
}
