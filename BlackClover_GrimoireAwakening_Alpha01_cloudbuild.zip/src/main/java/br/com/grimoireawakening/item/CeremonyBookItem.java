package br.com.grimoireawakening.item;

import br.com.grimoireawakening.magic.GrimoireRoller;
import br.com.grimoireawakening.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class CeremonyBookItem extends Item {
    private static final String DATA_KEY = "GrimoireAwakeningData";
    private static final String CHOSEN_KEY = "has_received_grimoire";

    public CeremonyBookItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (level.isClientSide) {
            return InteractionResultHolder.sidedSuccess(stack, true);
        }

        if (!(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResultHolder.fail(stack);
        }

        CompoundTag persistent = serverPlayer.getPersistentData();
        CompoundTag data = persistent.getCompound(DATA_KEY);

        if (data.getBoolean(CHOSEN_KEY)) {
            serverPlayer.sendSystemMessage(Component.translatable(
                    "message.grimoireawakening.already_chosen").withStyle(ChatFormatting.RED));
            return InteractionResultHolder.success(stack);
        }

        GrimoireRoller.Result result = GrimoireRoller.roll(level.random);
        data.putBoolean(CHOSEN_KEY, true);
        data.putString("magic_attribute", result.attribute().name());
        data.putString("grimoire_rarity", result.rarity().name());
        persistent.put(DATA_KEY, data);

        ItemStack grimoire = new ItemStack(ModItems.GRIMOIRE.get());
        CompoundTag grimoireTag = grimoire.getOrCreateTag();
        grimoireTag.putString("magic_attribute", result.attribute().name());
        grimoireTag.putString("grimoire_rarity", result.rarity().name());
        grimoire.setHoverName(Component.literal(
                "Grimório de " + result.attribute().displayName())
                .withStyle(ChatFormatting.GREEN));

        if (!serverPlayer.getInventory().add(grimoire)) {
            serverPlayer.drop(grimoire, false);
        }

        serverPlayer.sendSystemMessage(Component.translatable(
                "message.grimoireawakening.received",
                result.attribute().displayName()).withStyle(ChatFormatting.GOLD));

        stack.shrink(1);
        return InteractionResultHolder.success(stack);
    }
}
